package com.mobiledevelopment.ahmed.tipcalculator;

import android.app.ActivityOptions;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.animation.Animation;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.text.NumberFormat;

public class MainActivity extends AppCompatActivity {
    private TipCalculator tipCalc;
    private EditText billEditText;
    private RadioButton Ten;
    private RadioButton Fifteen;
    private RadioButton Twenty;
    private static float Percent;
    private Button calculate_button;
    private static float tip_amount;
    private static float total_amount;
    private static float tip;
    private static float total;


    @Override
    protected void onCreate( Bundle savedInstanceState ) {
        super.onCreate( savedInstanceState );
        tipCalc = new TipCalculator( 0.17f, 100.0f );
        setContentView( R.layout.activity_main );

        billEditText = ( EditText ) findViewById( R.id.amount_bill );
        calculate_button = ( Button ) findViewById( R.id.calculate_button );
        Ten = (RadioButton) findViewById(R.id.TenPercent);
        Fifteen = (RadioButton) findViewById(R.id.FifteenPercent);
        Twenty = (RadioButton) findViewById(R.id.TwentyPercent);
        Percent = 0;
        tip_amount = 0;
        total_amount = 0;
        tip = 0;
        total = 0;


        TextChangeHandler tch = new TextChangeHandler( );
        billEditText.addTextChangedListener( tch );


        View.OnClickListener calc = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (billEditText.getText().toString().equals("."))
                {
                    Toast.makeText(getApplicationContext(), "Enter a number for bill amount",
                            Toast.LENGTH_SHORT).show();
                }
                else if (Float.valueOf(billEditText.getText().toString()) == 0)
                {
                    Toast.makeText(getApplicationContext(), "Enter bill amount greater than 0",
                            Toast.LENGTH_SHORT).show();
                }
                else if (Percent != 0 && !billEditText.getText().toString().equals("")) {
                    Intent tipActivity = new Intent(v.getContext(), TipActivity.class);
                    tipActivity.putExtra("tip", tip);
                    tipActivity.putExtra("total", total);

                    Bundle anim = ActivityOptions.makeCustomAnimation(getApplicationContext(),
                            R.anim.slide_from_left, R.anim.fade_in_and_scale).toBundle();
                    startActivity(tipActivity, anim);
                }
                else if (Percent == 0 && billEditText.getText().toString().equals(""))
                {
                    Toast.makeText(getApplicationContext(), "Enter bill amount AND \nselect tip percentage",
                            Toast.LENGTH_SHORT).show();
                }
                else if (Percent == 0)
                {
                    Toast.makeText(getApplicationContext(), "Select tip percentage",
                            Toast.LENGTH_SHORT).show();
                }
                else if (billEditText.getText().toString().equals(""))
                {
                    Toast.makeText(getApplicationContext(), "Enter bill amount",
                            Toast.LENGTH_SHORT).show();
                }
            }
        };

        calculate_button.setOnClickListener(calc);


        RadioGroup radioGroup = (RadioGroup)findViewById(R.id.RadioGroup);
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                // find which radio button is selected
                if(checkedId == R.id.TenPercent) {
                    Toast.makeText(getApplicationContext(), "10",
                            Toast.LENGTH_SHORT).show();
                            Percent = 10;
                            calculate();
                } else if(checkedId == R.id.FifteenPercent) {
                    Toast.makeText(getApplicationContext(), "15",
                            Toast.LENGTH_SHORT).show();
                            Percent = 15;
                            calculate();
                } else if(checkedId == R.id.TwentyPercent){
                    Toast.makeText(getApplicationContext(), "20",
                            Toast.LENGTH_SHORT).show();
                            Percent = 20;
                            calculate();
                }
            }

        });
    }

    public void calculate( ) {
        String billString = billEditText.getText( ).toString( );

        TextView tipTextView =
                ( TextView ) findViewById( R.id.amount_tip );
        TextView totalTextView =
                ( TextView ) findViewById( R.id.amount_total );
        try {
            // convert billString and tipString to floats
            float billAmount = Float.parseFloat( billString );

            // update the Model
            tipCalc.setBill( billAmount );
            tipCalc.setTip( .01f * Percent );
            // ask Model to calculate tip and total amounts
            tip = tipCalc.tipAmount();
            total = tipCalc.totalAmount();
            // update the View with formatted tip and total amounts



        } catch( NumberFormatException nfe ) {
            // pop up an alert view here
        }
    }

    private class TextChangeHandler implements TextWatcher {
        public void afterTextChanged( Editable e ) {
            calculate( );
        }

        public void beforeTextChanged( CharSequence s, int start,
                                       int count, int after ) {
        }

        public void onTextChanged( CharSequence s, int start,
                                   int before, int after ) {
        }
    }

}
