package com.mobiledevelopment.ahmed.tipcalculator;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.text.NumberFormat;

public class TipActivity extends AppCompatActivity {
    public NumberFormat money = NumberFormat.getCurrencyInstance( );

    TextView tipTextView;
    TextView totalTextView;
    Button back_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tip);

        tipTextView = (TextView) findViewById(R.id.amount_tip);
        totalTextView = (TextView) findViewById(R.id.amount_total);
        back_button = (Button) findViewById(R.id.back_button);

        Bundle bundle = getIntent().getExtras();

        if(bundle.getFloat("tip")!= 0)
        {
            tipTextView.setText( money.format( bundle.getFloat("tip") ) );
        }
        if(bundle.getFloat("total") != 0)
        {
            totalTextView.setText( money.format( bundle.getFloat("total") ) );
        }

        View.OnClickListener back = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        };

        back_button.setOnClickListener(back);


    }

}
